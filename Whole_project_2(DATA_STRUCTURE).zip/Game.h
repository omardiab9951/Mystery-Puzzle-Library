#ifndef GAME_H
#define GAME_H

#include "Library.h"
#include <string>
using namespace std;

// ===================================
// فئة اللعبة
// ===================================
class Game {
private:
    Library* library;         // المكتبة
    BookNode* currentBook;    // الكتاب الحالي
    
    // ===================================
    // دوال مساعدة خاصة
    // ===================================
    
    // طباعة المقدمة
    void showIntro();
    
    // اختيار بوابة الدخول
    void chooseEntrance();
    
    // حل ألغاز الكتاب الحالي
    bool solvePuzzles();
    
    // اختيار المسار التالي
    void chooseNextPath();
    
    // التحقق من الإجابة
    bool checkAnswer(string playerAnswer, string correctAnswer);
    
public:
    // ===================================
    // البناء
    // ===================================
    Game(Library* lib);
    
    // ===================================
    // تشغيل اللعبة
    // ===================================
    void start();
};

#endif