#include "BookNode.h"
using namespace std;

// ===================================
// البناء الافتراضي
// ===================================
BookNode::BookNode() {
    id = 0;
    type = INTERMEDIATE;
    difficulty = EASY;
    clues = nullptr;
    clueCount = 0;
    next1 = nullptr;
    next2 = nullptr;
    visited = false;
    puzzleSolved = false;
}

// ===================================
// البناء بمعاملات
// ===================================
BookNode::BookNode(int bookId, BookType bookType, BookDifficulty bookDiff) {
    id = bookId;
    type = bookType;
    difficulty = bookDiff;
    clues = nullptr;
    clueCount = 0;
    next1 = nullptr;
    next2 = nullptr;
    visited = false;
    puzzleSolved = false;
}

// ===================================
// المدمر - ينضف الألغاز من الذاكرة
// ===================================
BookNode::~BookNode() {
    if (clues != nullptr) {
        delete[] clues;
        clues = nullptr;
    }
}

// ===================================
// عرض معلومات الكتاب
// ===================================
void BookNode::displayInfo() {
    cout << "\n================================" << endl;
    cout << "Book #" << id << endl;
    cout << "Type: " << getTypeString() << endl;
    cout << "Difficulty: " << getDifficultyString() << endl;
    cout << "Visited: " << (visited ? "Yes" : "No") << endl;
    cout << "Solved: " << (puzzleSolved ? "Yes" : "No") << endl;
    
    // عرض الألغاز
    if (clueCount > 0) {
        cout << "\nPuzzles in this book:" << endl;
        for (int i = 0; i < clueCount; i++) {
            cout << "  " << (i + 1) << ". " << clues[i].problem << endl;
        }
    }
    
    // عرض المسارات المتاحة
    cout << "\nAvailable Paths:" << endl;
    cout << "  Path 1: " << (next1 != nullptr ? "Available" : "None") << endl;
    cout << "  Path 2: " << (next2 != nullptr ? "Available" : "None") << endl;
    cout << "================================\n" << endl;
}

// ===================================
// تحقق: هل عندنا مسارين؟
// ===================================
bool BookNode::hasTwoPaths() {
    // الكتب السهلة بس اللي عندها مسارين
    return (difficulty == EASY && next2 != nullptr);
}

// ===================================
// تحويل نوع الكتاب لنص
// ===================================
string BookNode::getTypeString() {
    if (type == ENTRANCE) return "ENTRANCE";
    if (type == INTERMEDIATE) return "INTERMEDIATE";
    if (type == FINAL) return "FINAL";
    return "UNKNOWN";
}

// ===================================
// تحويل الصعوبة لنص
// ===================================
string BookNode::getDifficultyString() {
    if (difficulty == EASY) return "EASY";
    if (difficulty == HARD) return "HARD";
    return "UNKNOWN";
}

// ===================================
// تجهيز مكان للألغاز
// ===================================
void BookNode::setupClues(int count) {
    // لو في ألغاز قديمة، نمسحها الأول
    if (clues != nullptr) {
        delete[] clues;
    }
    
    // نعمل مساحة جديدة
    clueCount = count;
    clues = new Clue[count];
    
    // نفضي كل الألغاز
    for (int i = 0; i < count; i++) {
        clues[i].problem = "";
        clues[i].solution = "";
    }
}

// ===================================
// إضافة لغز في مكان معين
// ===================================
void BookNode::addClue(int index, string problem, string solution) {
    // نتأكد إن الـ index صح
    if (index >= 0 && index < clueCount) {
        clues[index].problem = problem;
        clues[index].solution = solution;
    }
}

// ===================================
// جلب لغز من مكان معين
// ===================================
Clue BookNode::getClue(int index) {
    // نتأكد إن الـ index صح
    if (index >= 0 && index < clueCount) {
        return clues[index];
    }
    
    // لو مش صح، نرجع لغز فاضي
    Clue empty;
    empty.problem = "";
    empty.solution = "";
    return empty;
}