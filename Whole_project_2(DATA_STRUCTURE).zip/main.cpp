#include "Library.h"
#include "Game.h"
#include "Utils.h"
#include <iostream>
using namespace std;

int main() {
    
    // ===================================
    // الخطوة 1: تحميل الألغاز
    // ===================================
    
    cout << "Loading puzzles from file..." << endl;
    
    string puzzleFile = "data/puzzles.txt";
    vector<Puzzle> puzzles = loadPuzzlesFromFile(puzzleFile);
    
    // نتحقق إننا حملنا ألغاز
    if (puzzles.empty()) {
        cout << "\nError: No puzzles found!" << endl;
        cout << "Make sure 'data/puzzles.txt' exists and has puzzles." << endl;
        return 1;
    }
    
    cout << "✓ Loaded " << puzzles.size() << " puzzles!\n" << endl;
    
    // ===================================
    // الخطوة 2: بناء المكتبة
    // ===================================
    
    Library library(puzzles);
    
    // نتحقق إن المكتبة سليمة
    if (!library.checkIfValid()) {
        cout << "\nError: Library structure is broken!" << endl;
        return 1;
    }
    
    cout << "✓ Library structure is valid!\n" << endl;
    
    // ===================================
    // الخطوة 3: بدء اللعبة
    // ===================================
    
    Game game(&library);
    game.start();
    
    // ===================================
    // النهاية
    // ===================================
    
    return 0;
}