#ifndef UTILS_H
#define UTILS_H

#include <string>
#include <vector>
using namespace std;

// ===================================
// هيكل اللغز
// ===================================
struct Puzzle {
    string riddle;   // السؤال
    string answer;   // الإجابة
    string category; // الفئة (اختياري)
};

// ===================================
// دوال معالجة النصوص
// ===================================

// مسح المسافات من أول وآخر النص
string trimText(const string& text);

// تحويل النص لحروف صغيرة
string toLowercase(const string& text);

// تنظيف النص (مسح مسافات + حروف صغيرة)
string cleanInput(const string& input);

// ===================================
// دوال تحميل الألغاز
// ===================================

// تحميل الألغاز من ملف
vector<Puzzle> loadPuzzlesFromFile(const string& filename);

// التحقق من صحة اللغز
bool isPuzzleValid(const Puzzle& puzzle);

// ===================================
// دوال عشوائية
// ===================================

// رقم عشوائي بين min و max
int randomNumber(int min, int max);

// خلط عناصر vector بشكل عشوائي
void shufflePuzzles(vector<Puzzle>& puzzles);

#endif