#ifndef BOOKNODE_H
#define BOOKNODE_H

#include <string>
#include <iostream>
using namespace std;

// ===================================
// الأنواع الأساسية
// ===================================

// نوع الكتاب
enum BookType {
    ENTRANCE,      // كتاب مدخل
    INTERMEDIATE,  // كتاب وسطي
    FINAL         // الكتاب النهائي
};

// مستوى الصعوبة
enum BookDifficulty {
    EASY,  // سهل - فيه مسارين
    HARD   // صعب - مسار واحد بس
};

// ===================================
// هيكل اللغز
// ===================================
struct Clue {
    string problem;   // السؤال
    string solution;  // الإجابة
};

// ===================================
// هيكل الكتاب (Node في الـ Linked List)
// ===================================
struct BookNode {
    // معلومات الكتاب الأساسية
    int id;                    // رقم الكتاب
    BookType type;             // نوعه (مدخل/وسطي/نهائي)
    BookDifficulty difficulty; // صعوبته
    
    // الألغاز الموجودة في الكتاب
    Clue* clues;      // مصفوفة الألغاز
    int clueCount;    // عدد الألغاز
    
    // المؤشرات للكتب التالية (Linked List Pointers)
    BookNode* next1;  // المسار الأول
    BookNode* next2;  // المسار الثاني (للكتب السهلة فقط)
    
    // حالة الكتاب
    bool visited;      // هل اللاعب زار الكتاب ده؟
    bool puzzleSolved; // هل حل الألغاز؟
    
    // ===================================
    // الدوال
    // ===================================
    
    // البناء الافتراضي
    BookNode();
    
    // البناء بمعاملات
    BookNode(int bookId, BookType bookType, BookDifficulty bookDiff);
    
    // المدمر - ينضف الذاكرة
    ~BookNode();
    
    // عرض معلومات الكتاب
    void displayInfo();
    
    // تحقق: هل الكتاب عنده مسارين؟
    bool hasTwoPaths();
    
    // دوال مساعدة لتحويل الـ enums لنص
    string getTypeString();
    string getDifficultyString();
    
    // دوال التعامل مع الألغاز
    void setupClues(int count);                              // تجهيز الألغاز
    void addClue(int index, string problem, string solution); // إضافة لغز
    Clue getClue(int index);                                 // جلب لغز
};

#endif