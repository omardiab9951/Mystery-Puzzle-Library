#include "Utils.h"
#include <fstream>
#include <iostream>
#include <algorithm>
#include <random>
#include <ctime>
using namespace std;

// ===================================
// مسح المسافات من أول وآخر النص
// ===================================
string trimText(const string& text) {
    // نلاقي أول حرف مش مسافة
    size_t start = text.find_first_not_of(" \t\n\r");
    
    // لو كل النص مسافات
    if (start == string::npos) {
        return "";
    }
    
    // نلاقي آخر حرف مش مسافة
    size_t end = text.find_last_not_of(" \t\n\r");
    
    // نرجع النص بدون المسافات
    return text.substr(start, end - start + 1);
}

// ===================================
// تحويل النص لحروف صغيرة
// ===================================
string toLowercase(const string& text) {
    string result = text;
    
    // نحول كل حرف لحرف صغير
    for (int i = 0; i < result.length(); i++) {
        result[i] = tolower(result[i]);
    }
    
    return result;
}

// ===================================
// تنظيف النص (trim + lowercase)
// ===================================
string cleanInput(const string& input) {
    string trimmed = trimText(input);
    return toLowercase(trimmed);
}

// ===================================
// تحميل الألغاز من ملف
// ===================================
vector<Puzzle> loadPuzzlesFromFile(const string& filename) {
    vector<Puzzle> puzzles;
    ifstream file(filename);
    
    // نتحقق إن الملف اتفتح
    if (!file.is_open()) {
        cout << "Error: Can't open file " << filename << endl;
        return puzzles;
    }
    
    string line;
    string currentCategory = "General";
    
    // نقرا الملف سطر سطر
    while (getline(file, line)) {
        line = trimText(line);
        
        // نتخطى السطور الفاضية
        if (line.empty()) {
            continue;
        }
        
        // لو السطر فيه [Category]
        if (line[0] == '[' && line[line.length()-1] == ']') {
            currentCategory = line.substr(1, line.length()-2);
            continue;
        }
        
        // نبحث عن "Riddle: " و " | Answer: "
        size_t riddlePos = line.find("Riddle: ");
        size_t answerPos = line.find(" | Answer: ");
        
        // لو لقيناهم
        if (riddlePos != string::npos && answerPos != string::npos) {
            // نستخرج السؤال
            string riddle = line.substr(riddlePos + 8, answerPos - (riddlePos + 8));
            riddle = trimText(riddle);
            
            // نستخرج الإجابة
            string answer = line.substr(answerPos + 11);
            answer = trimText(answer);
            
            // نضيف اللغز
            Puzzle puzzle;
            puzzle.riddle = riddle;
            puzzle.answer = answer;
            puzzle.category = currentCategory;
            
            puzzles.push_back(puzzle);
        }
    }
    
    file.close();
    
    cout << "Loaded " << puzzles.size() << " puzzles successfully!" << endl;
    return puzzles;
}

// ===================================
// التحقق من صحة اللغز
// ===================================
bool isPuzzleValid(const Puzzle& puzzle) {
    // اللغز صحيح لو السؤال والإجابة مش فاضيين
    return !puzzle.riddle.empty() && !puzzle.answer.empty();
}

// ===================================
// رقم عشوائي
// ===================================
int randomNumber(int min, int max) {
    static bool seeded = false;
    
    // نعمل seed مرة واحدة بس
    if (!seeded) {
        srand(time(0));
        seeded = true;
    }
    
    // نرجع رقم عشوائي بين min و max
    return min + (rand() % (max - min + 1));
}

// ===================================
// خلط الألغاز بشكل عشوائي
// ===================================
void shufflePuzzles(vector<Puzzle>& puzzles) {
    // نستخدم random engine للخلط
    static random_device rd;
    static mt19937 gen(rd());
    
    // نخلط الألغاز
    shuffle(puzzles.begin(), puzzles.end(), gen);
}