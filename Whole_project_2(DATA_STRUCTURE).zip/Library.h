#ifndef LIBRARY_H
#define LIBRARY_H

#include "BookNode.h"
#include "Utils.h"
#include <vector>
using namespace std;

// ===================================
// فئة المكتبة
// ===================================
class Library {
private:
    // الكتب الأساسية
    BookNode* entranceBooks[4];      // 4 كتب مداخل
    vector<BookNode*> middleBooks;   // الكتب الوسطية (10-15 كتاب)
    BookNode* finalBook;             // الكتاب النهائي
    
    // الألغاز المتاحة
    vector<Puzzle> allPuzzles;
    int nextPuzzleIndex;  // فهرس اللغز الجاي
    
    // ===================================
    // دوال مساعدة خاصة
    // ===================================
    
    // إنشاء كتب المداخل (4 كتب)
    void createEntranceBooks();
    
    // إنشاء الكتب الوسطية (10-15 كتاب)
    void createMiddleBooks();
    
    // إنشاء الكتاب النهائي
    void createFinalBook();
    
    // ربط الكتب ببعضها
    void linkAllBooks();
    
    // إضافة لغز لكتاب
    void addPuzzleToBook(BookNode* book, int puzzleCount);
    
public:
    // ===================================
    // البناء والتدمير
    // ===================================
    
    // البناء - ياخد الألغاز
    Library(vector<Puzzle> puzzles);
    
    // المدمر - ينضف الذاكرة
    ~Library();
    
    // ===================================
    // دوال الوصول
    // ===================================
    
    // جلب كتب المداخل
    BookNode** getEntranceBooks();
    
    // جلب الكتاب النهائي
    BookNode* getFinalBook();
    
    // عدد الكتب الوسطية
    int getMiddleBooksCount();
    
    // ===================================
    // دوال اختيارية للاختبار
    // ===================================
    
    // طباعة بنية المكتبة
    void printStructure();
    
    // التحقق من صحة المكتبة
    bool checkIfValid();
};

#endif