#include "Library.h"
#include <iostream>
using namespace std;

// ===================================
// البناء - إنشاء المكتبة
// ===================================
Library::Library(vector<Puzzle> puzzles) {
    // نحفظ الألغاز
    allPuzzles = puzzles;
    nextPuzzleIndex = 0;
    
    // نبدأ بـ null
    finalBook = nullptr;
    for (int i = 0; i < 4; i++) {
        entranceBooks[i] = nullptr;
    }
    
    // نبني المكتبة
    cout << "\nBuilding the Mystery Library..." << endl;
    
    createEntranceBooks();   // كتب المداخل
    createMiddleBooks();     // الكتب الوسطية
    createFinalBook();       // الكتاب النهائي
    linkAllBooks();          // نربط كل حاجة
    
    cout << "Library is ready!\n" << endl;
}

// ===================================
// المدمر - تنضيف الذاكرة
// ===================================
Library::~Library() {
    // نمسح كتب المداخل
    for (int i = 0; i < 4; i++) {
        if (entranceBooks[i] != nullptr) {
            delete entranceBooks[i];
            entranceBooks[i] = nullptr;
        }
    }
    
    // نمسح الكتب الوسطية
    for (int i = 0; i < middleBooks.size(); i++) {
        if (middleBooks[i] != nullptr) {
            delete middleBooks[i];
        }
    }
    middleBooks.clear();
    
    // نمسح الكتاب النهائي
    if (finalBook != nullptr) {
        delete finalBook;
        finalBook = nullptr;
    }
}

// ===================================
// إنشاء 4 كتب مداخل
// ===================================
void Library::createEntranceBooks() {
    cout << "Creating 4 entrance books..." << endl;
    
    for (int i = 0; i < 4; i++) {
        // نختار صعوبة عشوائية
        BookDifficulty diff = (randomNumber(0, 1) == 0) ? EASY : HARD;
        
        // ننشئ الكتاب
        BookNode* book = new BookNode(100 + i, ENTRANCE, diff);
        
        // نضيف لغز واحد
        addPuzzleToBook(book, 1);
        
        // نحفظه
        entranceBooks[i] = book;
    }
    
    cout << "  ✓ Created 4 entrance books" << endl;
}

// ===================================
// إنشاء الكتب الوسطية (10-15 كتاب)
// ===================================
void Library::createMiddleBooks() {
    // نختار عدد عشوائي من الكتب
    int count = randomNumber(10, 15);
    
    cout << "Creating " << count << " intermediate books..." << endl;
    
    for (int i = 0; i < count; i++) {
        // نختار صعوبة عشوائية
        BookDifficulty diff = (randomNumber(0, 1) == 0) ? EASY : HARD;
        
        // ننشئ الكتاب
        BookNode* book = new BookNode(200 + i, INTERMEDIATE, diff);
        
        // الكتب السهلة عندها لغزين، الصعبة لغز واحد
        int puzzleCount = (diff == EASY) ? 2 : 1;
        addPuzzleToBook(book, puzzleCount);
        
        // نضيفه للقائمة
        middleBooks.push_back(book);
    }
    
    cout << "  ✓ Created " << count << " intermediate books" << endl;
}

// ===================================
// إنشاء الكتاب النهائي
// ===================================
void Library::createFinalBook() {
    cout << "Creating final book..." << endl;
    
    // ننشئ الكتاب النهائي (دايما HARD)
    finalBook = new BookNode(999, FINAL, HARD);
    
    // نضيف اللغز النهائي الصعب
    addPuzzleToBook(finalBook, 1);
    
    cout << "  ✓ Created final book" << endl;
}

// ===================================
// إضافة لغز لكتاب
// ===================================
void Library::addPuzzleToBook(BookNode* book, int puzzleCount) {
    // نجهز مساحة للألغاز
    book->setupClues(puzzleCount);
    
    // نضيف الألغاز
    for (int i = 0; i < puzzleCount; i++) {
        // لو خلصت الألغاز، نرجع من الأول
        if (nextPuzzleIndex >= allPuzzles.size()) {
            nextPuzzleIndex = 0;
        }
        
        Puzzle p = allPuzzles[nextPuzzleIndex];
        book->addClue(i, p.riddle, p.answer);
        
        nextPuzzleIndex++;
    }
}

// ===================================
// ربط كل الكتب ببعضها
// ===================================
void Library::linkAllBooks() {
    cout << "Linking all books together..." << endl;
    
    int middleCount = middleBooks.size();
    
    // === ربط المداخل بالكتب الوسطية ===
    for (int i = 0; i < 4; i++) {
        // كل مدخل يروح لكتاب وسطي عشوائي
        int randomIndex = randomNumber(0, min(4, middleCount - 1));
        entranceBooks[i]->next1 = middleBooks[randomIndex];
        
        // لو المدخل سهل، نديله مسار تاني
        if (entranceBooks[i]->difficulty == EASY) {
            int randomIndex2 = randomNumber(0, min(4, middleCount - 1));
            
            // نتأكد إن المسار التاني مختلف
            if (randomIndex2 == randomIndex && middleCount > 1) {
                randomIndex2 = (randomIndex + 1) % middleCount;
            }
            
            entranceBooks[i]->next2 = middleBooks[randomIndex2];
        }
    }
    
    // === ربط الكتب الوسطية ببعضها ===
    for (int i = 0; i < middleCount; i++) {
        BookNode* current = middleBooks[i];
        
        // هنشوف الكتاب ده يروح فين
        // آخر 3 كتب يروحوا للكتاب النهائي
        if (i >= middleCount - 3) {
            current->next1 = finalBook;
            
            if (current->difficulty == EASY) {
                current->next2 = finalBook;
            }
        }
        // باقي الكتب يروحوا لكتب وسطية تانية
        else {
            // المسار الأول
            int nextIndex = randomNumber(i + 1, middleCount - 1);
            current->next1 = middleBooks[nextIndex];
            
            // لو الكتاب سهل، نديله مسار تاني
            if (current->difficulty == EASY) {
                int nextIndex2 = randomNumber(i + 1, middleCount - 1);
                
                // نتأكد إن المسار التاني مختلف
                if (nextIndex2 == nextIndex && nextIndex > i + 1) {
                    nextIndex2 = nextIndex - 1;
                }
                
                current->next2 = middleBooks[nextIndex2];
            }
        }
    }
    
    cout << "  ✓ All books linked successfully" << endl;
}

// ===================================
// جلب كتب المداخل
// ===================================
BookNode** Library::getEntranceBooks() {
    return entranceBooks;
}

// ===================================
// جلب الكتاب النهائي
// ===================================
BookNode* Library::getFinalBook() {
    return finalBook;
}

// ===================================
// عدد الكتب الوسطية
// ===================================
int Library::getMiddleBooksCount() {
    return middleBooks.size();
}

// ===================================
// طباعة بنية المكتبة (للاختبار)
// ===================================
void Library::printStructure() {
    cout << "\n========================================" << endl;
    cout << "       LIBRARY STRUCTURE" << endl;
    cout << "========================================\n" << endl;
    
    // المداخل
    cout << "ENTRANCE BOOKS (4):" << endl;
    for (int i = 0; i < 4; i++) {
        cout << "  Book #" << entranceBooks[i]->id;
        cout << " (" << entranceBooks[i]->getDifficultyString() << ")";
        cout << " -> Book #" << entranceBooks[i]->next1->id;
        
        if (entranceBooks[i]->next2 != nullptr) {
            cout << " & Book #" << entranceBooks[i]->next2->id;
        }
        cout << endl;
    }
    
    // الكتب الوسطية
    cout << "\nINTERMEDIATE BOOKS (" << middleBooks.size() << "):" << endl;
    for (int i = 0; i < middleBooks.size(); i++) {
        BookNode* book = middleBooks[i];
        cout << "  Book #" << book->id;
        cout << " (" << book->getDifficultyString() << ")";
        
        if (book->next1 != nullptr) {
            cout << " -> Book #" << book->next1->id;
        }
        if (book->next2 != nullptr) {
            cout << " & Book #" << book->next2->id;
        }
        cout << endl;
    }
    
    // الكتاب النهائي
    cout << "\nFINAL BOOK:" << endl;
    cout << "  Book #" << finalBook->id << endl;
    
    cout << "\n========================================\n" << endl;
}

// ===================================
// التحقق من صحة المكتبة
// ===================================
bool Library::checkIfValid() {
    // نتحقق من المداخل
    for (int i = 0; i < 4; i++) {
        if (entranceBooks[i] == nullptr) return false;
        if (entranceBooks[i]->next1 == nullptr) return false;
    }
    
    // نتحقق من الكتاب النهائي
    if (finalBook == nullptr) return false;
    
    // نتحقق من الكتب الوسطية
    for (int i = 0; i < middleBooks.size(); i++) {
        BookNode* book = middleBooks[i];
        
        if (book == nullptr) return false;
        if (book->next1 == nullptr) return false;
        
        // الكتب السهلة لازم يكون عندها next2
        if (book->difficulty == EASY && book->next2 == nullptr) {
            return false;
        }
    }
    
    return true;
}