#include "Game.h"
#include "Utils.h"
#include <iostream>
#include <limits>
using namespace std;

// ===================================
// البناء
// ===================================
Game::Game(Library* lib) {
    library = lib;
    currentBook = nullptr;
}

// ===================================
// طباعة مقدمة اللعبة
// ===================================
void Game::showIntro() {
    cout << "\n================================================" << endl;
    cout << "|                                              |" << endl;
    cout << "|      WELCOME TO THE MYSTERY LIBRARY         |" << endl;
    cout << "|                                              |" << endl;
    cout << "|   Solve puzzles to reach the final book     |" << endl;
    cout << "|        and escape the library!               |" << endl;
    cout << "|                                              |" << endl;
    cout << "================================================\n" << endl;
}

// ===================================
// اختيار بوابة الدخول
// ===================================
void Game::chooseEntrance() {
    BookNode** entrances = library->getEntranceBooks();
    
    cout << "================================================" << endl;
    cout << " You see 4 mysterious entrance gates..." << endl;
    cout << "================================================\n" << endl;
    
    // نعرض الخيارات
    for (int i = 0; i < 4; i++) {
        cout << "  [" << (i + 1) << "] Gate " << (i + 1) << " - ";
        
        if (entrances[i]->difficulty == EASY) {
            cout << "EASY (You'll have 2 choices later)";
        } else {
            cout << "HARD (Only 1 path forward)";
        }
        cout << endl;
    }
    
    // نطلب من اللاعب يختار
    int choice = 0;
    bool validChoice = false;
    
    while (!validChoice) {
        cout << "\n>> Choose your gate (1-4): ";
        cin >> choice;
        
        // نتحقق من الإدخال
        if (cin.fail()) {
            // لو الإدخال مش رقم
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Please enter a number between 1 and 4!" << endl;
        }
        else if (choice < 1 || choice > 4) {
            // لو الرقم خارج النطاق
            cout << "Please choose 1, 2, 3, or 4!" << endl;
        }
        else {
            // الاختيار صحيح
            validChoice = true;
        }
    }
    
    // ننضف الـ input buffer
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    
    // نختار البوابة
    currentBook = entrances[choice - 1];
    
    cout << "\n>> You step through Gate " << choice << "...\n" << endl;
}

// ===================================
// حل ألغاز الكتاب الحالي
// ===================================
bool Game::solvePuzzles() {
    cout << "================================================" << endl;
    cout << " Book Type: " << currentBook->getTypeString() << endl;
    cout << " Difficulty: " << currentBook->getDifficultyString() << endl;
    cout << "================================================\n" << endl;
    
    int puzzleCount = currentBook->clueCount;
    
    // لو مفيش ألغاز
    if (puzzleCount == 0) {
        cout << "This book has no puzzles. Moving forward...\n" << endl;
        currentBook->puzzleSolved = true;
        currentBook->visited = true;
        return true;
    }
    
    cout << "This book contains " << puzzleCount << " puzzle(s).\n" << endl;
    
    // نحل كل لغز
    for (int i = 0; i < puzzleCount; i++) {
        Clue puzzle = currentBook->getClue(i);
        
        cout << "+---------------------------------------------+" << endl;
        cout << "|  PUZZLE " << (i + 1) << " of " << puzzleCount << "                             |" << endl;
        cout << "+---------------------------------------------+\n" << endl;
        
        // عدد المحاولات المسموحة
        int maxAttempts = 3;
        bool solved = false;
        
        // نجرب 3 مرات
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            cout << "Riddle: " << puzzle.problem << endl;
            cout << "Attempts: " << attempt << "/" << maxAttempts << endl;
            cout << "\n>> Your Answer: ";
            
            // نقرا الإجابة
            string playerAnswer;
            getline(cin, playerAnswer);
            
            // نتحقق من الإجابة
            if (checkAnswer(playerAnswer, puzzle.solution)) {
                cout << "\n>> CORRECT! Well done!" << endl;
                solved = true;
                break;
            }
            else {
                // إجابة خاطئة
                if (attempt < maxAttempts) {
                    cout << "\n>> WRONG! Try again..." << endl;
                }
                else {
                    // خلصت المحاولات
                    cout << "\n>> WRONG! No attempts left!" << endl;
                    cout << "The correct answer was: " << puzzle.solution << endl;
                    cout << "\n*** GAME OVER ***" << endl;
                    return false;
                }
            }
            cout << endl;
        }
        
        // لو ماحلش اللغز
        if (!solved) {
            return false;
        }
    }
    
    // حل كل الألغاز بنجاح
    currentBook->puzzleSolved = true;
    currentBook->visited = true;
    
    cout << "================================================" << endl;
    cout << "   >> All puzzles solved! Great job!" << endl;
    cout << "================================================\n" << endl;
    
    return true;
}

// ===================================
// التحقق من الإجابة
// ===================================
bool Game::checkAnswer(string playerAnswer, string correctAnswer) {
    // ننضف الإجابتين ونقارنهم
    return cleanInput(playerAnswer) == cleanInput(correctAnswer);
}

// ===================================
// اختيار المسار التالي
// ===================================
void Game::chooseNextPath() {
    // لو وصلنا للكتاب النهائي
    if (currentBook->type == FINAL) {
        return;
    }
    
    // نشوف عندنا كام مسار
    bool hasTwoPaths = currentBook->hasTwoPaths();
    
    if (!hasTwoPaths) {
        // مسار واحد بس
        cout << "================================================" << endl;
        cout << " Following the only path forward..." << endl;
        cout << "================================================\n" << endl;
        
        currentBook = currentBook->next1;
    }
    else {
        // مسارين - اللاعب يختار
        cout << "================================================" << endl;
        cout << "      THE PATH SPLITS IN TWO!" << endl;
        cout << "================================================\n" << endl;
        
        cout << "  [1] Take the LEFT path" << endl;
        cout << "  [2] Take the RIGHT path" << endl;
        
        int choice = 0;
        bool validChoice = false;
        
        while (!validChoice) {
            cout << "\n>> Which path? (1 or 2): ";
            cin >> choice;
            
            if (cin.fail()) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << "Please enter 1 or 2!" << endl;
            }
            else if (choice == 1 || choice == 2) {
                validChoice = true;
            }
            else {
                cout << "Please enter 1 or 2!" << endl;
            }
        }
        
        // ننضف الـ input buffer
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        
        // نختار المسار
        if (choice == 1) {
            cout << "\n>> You take the LEFT path...\n" << endl;
            currentBook = currentBook->next1;
        }
        else {
            cout << "\n>> You take the RIGHT path...\n" << endl;
            currentBook = currentBook->next2;
        }
    }
}

// ===================================
// تشغيل اللعبة الرئيسي
// ===================================
void Game::start() {
    // نعرض المقدمة
    showIntro();
    
    // نختار بوابة الدخول
    chooseEntrance();
    
    // نبدأ اللعبة
    while (currentBook != nullptr) {
        
        // نحل ألغاز الكتاب الحالي
        bool puzzlesSolved = solvePuzzles();
        
        // لو فشلنا في الحل
        if (!puzzlesSolved) {
            cout << "\nYour journey ends here..." << endl;
            cout << "Better luck next time!\n" << endl;
            
            cout << "Press Enter to exit...";
            cin.get();
            return;
        }
        
        // نشوف لو وصلنا للكتاب النهائي
        if (currentBook->type == FINAL) {
            // فزنا!
            cout << "\n================================================" << endl;
            cout << "|                                              |" << endl;
            cout << "|           *** CONGRATULATIONS! ***          |" << endl;
            cout << "|                                              |" << endl;
            cout << "|    You solved the final mystery book!       |" << endl;
            cout << "|       The library sets you free!             |" << endl;
            cout << "|                                              |" << endl;
            cout << "================================================\n" << endl;
            
            cout << "Press Enter to exit...";
            cin.get();
            break;
        }
        
        // ننتقل للكتاب التالي
        chooseNextPath();
    }
    
    cout << "Thank you for playing!\n" << endl;
}